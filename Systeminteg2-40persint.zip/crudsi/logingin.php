

<?php 

include 'config.php';
session_start();
if (isset($_POST['submit']))
{
    $conn=mysqli_connect("localhost","root","","system") or die ("Error in connection");
    $_SESSION['email']=$_POST['email'];
    $email = $_POST['email'];
    $pswrd=md5($_POST['pwd']);
    $_SESSION['firstname'] = $email;
    //Insertion of Records
    $hanap="SELECT * from user where (email='$email' AND password ='$pswrd')";
    $result=mysqli_query($conn,$hanap);
    $bilang=mysqli_num_rows($result);

    if ($bilang === 1) {

        $row = $result->fetch_assoc();
        $role = $row['role'];

        if($role == 'admin') {

            // echo "Welcome, Admin!";
            $_SESSION['user_name'] = $email;
            header('location: view.php');

        }elseif ($role == 'faculty') {

            // echo "Welcome, faculty";
            $_SESSION['user_name'] = $email;
            header('location: faculty.php');

        }elseif ($role == 'student') {

            // echo "Welcome, Student";
            $_SESSION['user_name'] = $email;
            header('location: student.php');

        } else {

            echo "Invalid Username And Password";

        }

    }
    //     echo "Welcome Admin successfully";
    //     // header ("Location:welcome.php");
    // else{
    //     echo "<script>alert('Your Email or password is incorrect')</script>";
    // }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="logstyle.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body>
    
<!-- <form method="post" action="logingin.php">
    <input type="text" name="email" placeholder="Email" required><br>
    <input type="password" name="pwd" placeholder="Password" required><br>
    <input type="submit" name="submit" value="Login">
</form> -->

<div class="container">
        
        <h2>Login</h2>
  
    
    <form action="" method="post">
        <div class="icon">
            <i class="uil uil-envelope icon"></i>
        <input type="text" name="email" placeholder="Email" autocomplete="off" required>
        </div>
            <div class="icon">
                <i class="uil uil-lock icon"></i>
        <input type="password" name="pwd" placeholder="Password" autocomplete="off" required>
            </div>
        <input type="submit" name="submit" value="Login">

    </form>
</div>


</body>
</html>
