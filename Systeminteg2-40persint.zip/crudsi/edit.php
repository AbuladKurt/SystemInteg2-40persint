<?php

    include 'config.php';
    session_start();

    if(!$conn) {

        die('Error in db' . mysqli_error($conn));

    } else {

        $id = $_GET['id'];
        $qry = "SELECT * FROM user WHERE user_id = $id";
        $run = $conn->query($qry);
        if ($run->num_rows > 0) {

         while($row = $run -> fetch_assoc()) {
            $userfname = $row['firstname'];
            $userlname = $row['lastname'];
            $usermname = $row['middlename'];
            $useremail = $row['email'];
            $username = $row['username'];
            $userpassword = $row['password'];
            $usercontact = $row['contact'];
            $usergender = $row['gender'];
            $userrole = $row['role'];
            
         }

        }

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="try.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit user</title>
</head>
<body>
<div class="container">
    <div class="navlinks">
       
        <ul>
        <li><a href="view.php">
                    <?php

                        $email = $_SESSION['user_name'];

                        if ($email == true) {



                        } else {

                            header('location:logingin.php');

                        }

                        echo $_SESSION['firstname'];
                     
                    ?>
                </a></li>
            <li><a class="btn" href="view.php">View Users</a></li>
            <li><a class="btn" href="user.php">Add User</a></li>
            <li><a class="btn" href="#">Contacts</a></li>
            <li><a class="btn" href="#">Mission and Vision</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
    
    </div>
    <div class="form-container">
    <form action="" method="post">
    <label>First name</label>
    <input type="text" name="fname" value="<?php echo $userfname; ?>">
    <label>Last name</label>
    <input type="text" name="lname" value="<?php echo $userlname; ?>">
    <label>Middle name</label>
    <input type="text" name="mname" value="<?php echo $usermname; ?>">
    <label>Email</label>
    <input type="email" name="email" value="<?php echo $useremail; ?>">
    <label>Username</label>
    <input type="text" name="username" value="<?php echo $username; ?>">
    <label>Password</label>
    <input type="password" name="password" value="<?php echo $userpassword; ?>">
    <label>Contact</label>
    <input type="text" name="contact" value="<?php echo $usercontact; ?>">
    <div class="gender">
    <input type="radio" name="gender" value="Male">Male
    <input type="radio" name="gender" value="Female">Female 
    </div>
    <label>Role</label>
    <select name="role">
    <option value="">Select</option>
    <option value="Admin">Admin</option>
    <option value="Faculty">Faculty</option>
    <option value="Student">Student</option>
    </select>
    <br>
    <input type="submit" name="update" value="update">
    </form>
    </div>

</div>
</body>
</html>

<?php 

    if(isset($_POST['update'])) {

        $id = $_GET['id'];
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $mname = $_POST['mname'];
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password =md5($_POST['password']);
        // $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $contact = $_POST['contact'];
        $gender = $_POST['gender'];
        $role = $_POST['role'];

       
        
        $qry = "UPDATE user SET firstname = '$fname', lastname = '$lname', middlename = '$mname', email = '$email', username = '$username', password = '$password', contact = '$contact', gender = '$gender', role = '$role' WHERE user_id = $id";
        // $qry = "UPDATE user SET firstname = '$fname', lastname = '$lname', middlename = '$mname', email = '$email', username = '$username', password = '$hashedPassword', contact = '$contact', gender = '$gender', role = '$role' WHERE user_id = $id";


        if($conn->query($qry) == TRUE) {

            header('location:view.php');

        } else {

            echo mysqli_error($conn);

        }


    }

?>