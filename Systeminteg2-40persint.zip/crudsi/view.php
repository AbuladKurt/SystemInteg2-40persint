<?php 

    include 'config.php';
    session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="try.css">
    <title>View</title>
</head>
<body>
    
<div class="container">
    <div class="navlinks">
  
    
        <ul>
            <li><a href="view.php">
                    <?php

                        $email = $_SESSION['user_name'];

                        if ($email == true) {



                        } else {

                            header('location:logingin.php');

                        }

                        echo $_SESSION['firstname'];
                     
                    ?>
                </a></li>
            <li><a class="btn" href="view.php">View Users</a></li>
            <li><a class="btn" href="user.php">Add User</a></li>
            <li><a class="btn" href="#">Contacts</a></li>
            <li><a class="btn" href="#">Mission and Vision</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
    
    </div>
    
    <div class="table">
        <h1>User list</h1>
        <table>

            <tr>
                    <th>S#</th>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Middle name</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Contact</th>
                    <th>Gender</th>
                    <th>Role</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
        <tr>
    <!-- VIEW PAGE PHP -->
        <?php
           
           $i = 1;
           $qry = "SELECT * FROM user";
           $run = $conn->query($qry);
           if ($run->num_rows > 0) {

            while($row = $run -> fetch_assoc()) {

                $id = $row['user_id'];


        ?>
        <!-- VIEW PAGE AGAIN -->
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $row['firstname']; ?></td>
            <td><?php echo $row['lastname']; ?></td>
            <td><?php echo $row['middlename']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td><?php echo $row['password']; ?></td>
            <td><?php echo $row['contact']; ?></td>
            <td><?php echo $row['gender']; ?></td>
            <td><?php echo $row['role']; ?></td>
            <td>
                <a class="edit" href="edit.php?id=<?php echo $id; ?>">Edit   <svg class="svg" viewBox="0 0 512 512">
        <path d="M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1v32c0 8.8 7.2 16 16 16h32zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z"></path></svg></a>
                
            </td>
            <td><a class="delete" href="delete.php?id=<?php echo $id; ?>" onclick="return confirm('Are you sure?')"><button class="noselect"><span class="text">Delete</span><span class="icon"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M24 20.188l-8.315-8.209 8.2-8.282-3.697-3.697-8.212 8.318-8.31-8.203-3.666 3.666 8.321 8.24-8.206 8.313 3.666 3.666 8.237-8.318 8.285 8.203z"></path></svg></span></button></a></td>
        </tr>
        </tr>
        <?php 
            }

           }

        
        ?>

        
    </table>
        </div>
        </div>
</body>
</html>